import unittest
from datetime import date
from unittest.mock import patch

from app import create_app
from extensions import db
from models import ExpenseCategory
from services.ai_service import generate_recommendation, normalize_response


class FinanceAdvisorTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app(
            {
                "TESTING": True,
                "WTF_CSRF_ENABLED": False,
                "SECRET_KEY": "test-secret",
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SESSION_COOKIE_SECURE": False,
                "SESSION_COOKIE_SAMESITE": "Lax",
                "GEMINI_API_KEY": "",
                "OPENAI_API_KEY": "",
            }
        )
        self.client = self.app.test_client()

    def register(self, email="test@example.com"):
        return self.client.post(
            "/register",
            data={
                "name": "Test User",
                "email": email,
                "password": "securepass123",
                "confirm_password": "securepass123",
            },
            follow_redirects=True,
        )

    def test_public_health_and_manifest(self):
        self.assertEqual(self.client.get("/health").status_code, 200)
        manifest = self.client.get("/manus-routes.json")
        self.assertEqual(manifest.status_code, 200)
        self.assertIn('"routes"', manifest.get_data(as_text=True))

    def test_protected_route_redirects(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.headers["Location"])

    def test_auth_finance_budget_report_and_ai_fallback(self):
        response = self.register()
        self.assertEqual(response.status_code, 200)
        self.assertIn("Good to see you", response.get_data(as_text=True))

        today = date.today()
        income = self.client.post(
            "/income/add",
            data={"source": "Salary", "amount": "5000", "date": today.isoformat()},
            follow_redirects=True,
        )
        self.assertEqual(income.status_code, 200)
        self.assertIn("Income record added", income.get_data(as_text=True))

        with self.app.app_context():
            category_id = ExpenseCategory.query.filter_by(name="Food").first().id

        expense = self.client.post(
            "/expenses/add",
            data={
                "amount": "120",
                "category_id": category_id,
                "date": today.isoformat(),
                "note": "Groceries",
            },
            follow_redirects=True,
        )
        self.assertEqual(expense.status_code, 200)
        self.assertIn("Expense recorded", expense.get_data(as_text=True))

        budget = self.client.post(
            "/budgets/add",
            data={
                "category_id": category_id,
                "amount": "100",
                "year": today.year,
                "month": today.month,
            },
            follow_redirects=True,
        )
        self.assertEqual(budget.status_code, 200)
        self.assertIn("Overspending detected", budget.get_data(as_text=True))

        dashboard = self.client.get(f"/?year={today.year}&month={today.month}")
        self.assertEqual(dashboard.status_code, 200)
        self.assertIn("Cash flow trend", dashboard.get_data(as_text=True))

        chart_data = self.client.get(f"/api/chart-data?year={today.year}&month={today.month}")
        self.assertEqual(chart_data.status_code, 200)
        self.assertIn("Food", chart_data.get_data(as_text=True))

        report = self.client.get(f"/reports?year={today.year}&month={today.month}")
        self.assertEqual(report.status_code, 200)
        self.assertIn("Monthly report", report.get_data(as_text=True))

        ai = self.client.post(
            "/ai/generate/health",
            data={"year": today.year, "month": today.month},
            follow_redirects=True,
        )
        self.assertEqual(ai.status_code, 200)
        self.assertIn("AI is not configured yet", ai.get_data(as_text=True))

    def test_csrf_rejects_missing_token(self):
        csrf_app = create_app(
            {
                "TESTING": True,
                "WTF_CSRF_ENABLED": True,
                "SECRET_KEY": "csrf-secret",
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SESSION_COOKIE_SECURE": False,
                "SESSION_COOKIE_SAMESITE": "Lax",
            }
        )
        response = csrf_app.test_client().post(
            "/register",
            data={
                "name": "No Token",
                "email": "notoken@example.com",
                "password": "securepass123",
                "confirm_password": "securepass123",
            },
        )
        self.assertEqual(response.status_code, 400)

    def test_invalid_periods_fall_back_without_500(self):
        self.register("period@example.com")
        for path in [
            "/?year=999999&month=9",
            "/reports?year=999999&month=9",
            "/budgets?year=999999&month=9",
            "/api/chart-data?year=999999&month=9",
            "/ai/recommendations?year=999999&month=9",
        ]:
            response = self.client.get(path)
            self.assertLess(response.status_code, 500, path)

    def test_ai_normalization_and_provider_fallback(self):
        normalized = normalize_response(
            {
                "financial_health_score": 150,
                "budget_plan": ["ignore this", {"category": "Food", "amount": "125", "rationale": 4}],
                "savings_recommendations": {"not": "a list"},
                "recommendations": "Build an emergency fund",
            },
            "health",
        )
        self.assertEqual(normalized["financial_health_score"], 100)
        self.assertEqual(len(normalized["budget_plan"]), 1)
        self.assertEqual(normalized["budget_plan"][0]["amount"], 125.0)
        self.assertEqual(normalized["savings_recommendations"], [])
        self.assertEqual(normalized["actionable_recommendations"], ["Build an emergency fund"])

        config = {
            "GEMINI_API_KEY": "gemini-test",
            "OPENAI_API_KEY": "openai-test",
            "OPENAI_MODEL": "test-model",
            "AI_TEMPERATURE": 0.2,
            "FLASK_ENV": "testing",
        }
        with patch("services.ai_service._call_gemini", side_effect=RuntimeError("Gemini unavailable")), patch(
            "services.ai_service._call_openai",
            return_value='{"summary":"OpenAI fallback worked","financial_health_score":72}',
        ) as openai_call:
            result = generate_recommendation("health", {"profile": {"currency": "USD"}}, config)
        self.assertTrue(result["ok"])
        self.assertEqual(result["provider"], "openai")
        self.assertEqual(result["data"]["financial_health_score"], 72.0)
        openai_call.assert_called_once()

    def test_preview_session_cookie_is_cross_site_compatible(self):
        csrf_app = create_app(
            {
                "TESTING": True,
                "WTF_CSRF_ENABLED": True,
                "SECRET_KEY": "cookie-test-secret",
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SESSION_COOKIE_SECURE": False,
                "SESSION_COOKIE_SAMESITE": "Lax",
            }
        )
        cookie_client = csrf_app.test_client()
        local_response = cookie_client.get("/login")
        local_cookie = "\n".join(local_response.headers.getlist("Set-Cookie"))
        self.assertIn("SameSite=Lax", local_cookie)
        self.assertNotIn("; Secure", local_cookie)

        preview_response = cookie_client.get(
            "/login",
            headers={"X-Forwarded-Proto": "https"},
        )
        preview_cookie = "\n".join(preview_response.headers.getlist("Set-Cookie"))
        self.assertIn("SameSite=None", preview_cookie)
        self.assertIn("; Secure", preview_cookie)


if __name__ == "__main__":
    unittest.main()
