(() => {
  document.querySelectorAll('.delete-form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm('Delete this record? This cannot be undone.')) event.preventDefault();
    });
  });

  if (window.financeChartUrl && window.Chart) {
    fetch(window.financeChartUrl)
      .then((response) => response.json())
      .then((data) => {
        const palette = ['#7257e8', '#f07c5f', '#30a878', '#4f8bc9', '#d9576d', '#e5b84d', '#8b72c8'];
        const expenseCanvas = document.getElementById('expenseChart');
        if (expenseCanvas && data.breakdown.length) {
          new Chart(expenseCanvas, {
            type: 'doughnut',
            data: {
              labels: data.breakdown.map((item) => item.category),
              datasets: [{ data: data.breakdown.map((item) => item.amount), backgroundColor: palette, borderWidth: 4, borderColor: '#fff' }],
            },
            options: { responsive: true, maintainAspectRatio: false, cutout: '68%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, usePointStyle: true, font: { family: 'DM Sans', size: 11 } } } } },
          });
        }
        const trendCanvas = document.getElementById('trendChart');
        if (trendCanvas && data.trend.length) {
          new Chart(trendCanvas, {
            type: 'line',
            data: {
              labels: data.trend.map((item) => item.label),
              datasets: [
                { label: 'Income', data: data.trend.map((item) => item.income), borderColor: '#7257e8', backgroundColor: 'rgba(114,87,232,.09)', fill: true, tension: .35, pointRadius: 3 },
                { label: 'Expenses', data: data.trend.map((item) => item.expenses), borderColor: '#f07c5f', backgroundColor: 'rgba(240,124,95,.04)', fill: true, tension: .35, pointRadius: 3 },
              ],
            },
            options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, usePointStyle: true, font: { family: 'DM Sans', size: 11 } } } }, scales: { y: { beginAtZero: true, grid: { color: '#f0eef5' }, ticks: { font: { family: 'DM Sans', size: 10 } } }, x: { grid: { display: false }, ticks: { font: { family: 'DM Sans', size: 10 } } } } },
          });
        }
      })
      .catch(() => {});
  }

  window.setTimeout(() => {
    document.querySelectorAll('.flash').forEach((flash) => flash.remove());
  }, 7000);
})();
