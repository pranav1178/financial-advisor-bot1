# Personal Finance Advisor Bot

A complete Flask-based personal finance workspace for tracking income and expenses, planning category budgets, measuring savings goals, reviewing monthly reports, and getting optional structured AI guidance from Google Gemini or OpenAI.

## What is included

- Secure registration, login, logout, password hashing, protected routes, session cookies, flash messages, and CSRF protection.
- Profile fields for name, monthly income, financial goals, and currency.
- Income and expense CRUD, custom/default categories, savings goals with progress, and monthly summaries.
- Category budgets with actual-vs-limit comparisons and overspending alerts.
- Dashboard cards, expense breakdown, six-month cash-flow trend, budget performance, savings progress, and category analytics using Chart.js.
- Monthly printable report with browser “Print / download PDF” support.
- AI coach actions for personalized budgets, spending analysis, savings recommendations, financial health score, cost optimization, and emergency-fund guidance. Gemini is preferred; OpenAI is the fallback.
- SQLite by default, with PostgreSQL-compatible configuration through `DATABASE_URL`.
- Optional `pyngrok` startup mode and a documented standalone Ngrok alternative.

## Requirements

- Python 3.10+ (the sandbox has Python 3.12 available)
- A modern browser
- Optional: a Gemini API key, OpenAI API key, and/or Ngrok auth token

## Local setup

From the project directory:

```bash
cd /home/ubuntu/financebot
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set at least a strong `SECRET_KEY`. AI and Ngrok values are optional. The default database is a local `finance.db` SQLite file. The app creates tables automatically on first start; you can also initialize explicitly:

The default session settings are compatible with the HTTPS Cloud Preview iframe (`SameSite=None; Secure`). The included `.env.example` intentionally overrides them for direct local HTTP development with `SESSION_COOKIE_SECURE=false` and `SESSION_COOKIE_SAMESITE=Lax`.

```bash
flask --app app init-db
```

Start the application:

```bash
python app.py
```

Open [http://127.0.0.1:3000](http://127.0.0.1:3000). To use another port, set `PORT` in `.env`, for example `PORT=5000`.

## AI configuration

The application never hard-codes or displays provider keys. Put the values in the local `.env` file:

```dotenv
GEMINI_API_KEY=your-gemini-key
OPENAI_API_KEY=your-openai-key
OPENAI_MODEL=gpt-4o-mini
```

If both keys are present, Gemini is used first. If Gemini is absent, OpenAI is used. If neither is present, finance tracking, budgets, dashboards, and reports continue to work; AI actions show a clear configuration message instead of failing the application.

## PostgreSQL configuration

Install the included PostgreSQL driver is already covered by `requirements.txt`, then set a PostgreSQL URL in `.env`:

```dotenv
DATABASE_URL=postgresql://username:password@localhost:5432/financebot
```

The configuration normalizes `postgres://` and `postgresql://` to the SQLAlchemy psycopg2 dialect. SQLite remains the default for local development.

## Expose locally with Ngrok

### Option A: built-in pyngrok mode

Add your Ngrok token to `.env`:

```dotenv
NGROK_AUTH_TOKEN=your-ngrok-auth-token
```

Then run:

```bash
source .venv/bin/activate
python app.py --ngrok
```

The terminal prints both the local URL and the public HTTPS Ngrok URL. Keep the process running while sharing the URL.

### Option B: standalone Ngrok CLI

Start Flask in one terminal:

```bash
source .venv/bin/activate
python app.py
```

In a second terminal, after installing and authenticating the Ngrok CLI:

```bash
ngrok config add-authtoken YOUR_TOKEN
ngrok http 3000
```

Copy the `Forwarding` HTTPS URL shown by Ngrok. A tunnel is temporary unless you configure a reserved domain in Ngrok. Do not use this Flask development server, Ngrok, or SQLite as a production deployment strategy.

## Useful routes

- `/` — authenticated dashboard
- `/register`, `/login`, `/logout` — authentication
- `/profile` — profile settings
- `/income`, `/expenses`, `/categories`, `/savings` — financial tracking
- `/budgets` — monthly budgets and actuals
- `/ai/recommendations` — AI coach
- `/reports` — printable monthly report
- `/health` — unauthenticated runtime health check
- `/manus-routes.json` — WebDev route manifest

## Project structure

```text
app.py
config.py
extensions.py
models.py
forms.py
routes/
  auth.py
  finance.py
  budget.py
  ai.py
  dashboard.py
services/
  ai_service.py
  finance_service.py
templates/
static/css/style.css
static/js/app.js
tests/test_app.py
requirements.txt
.env.example
```

## Testing checklist

Run the automated smoke suite:

```bash
source .venv/bin/activate
python -m unittest discover -s tests -v
```

Manual checklist:

- **Auth:** register a new user, verify login/logout, try a protected page while signed out, and update profile name/income/goals/currency.
- **Income:** add, edit, and delete an income record; confirm it appears in the dashboard and report totals.
- **Expenses:** add, edit, and delete expenses across default and custom categories; verify category analytics.
- **Budget:** set a category limit lower than actual spending and confirm the overspending alert and budget bar.
- **Savings:** create a goal, update progress, and confirm the percentage/progress bar.
- **AI:** configure one provider key, generate each coach action, confirm structured recommendations are saved, then test the no-key message with both keys absent.
- **Dashboard:** verify cards, pie/doughnut breakdown, six-month trend, budget performance, and savings progress.
- **Reports:** change the month, review category detail and AI recommendations, and use “Print / download PDF”.
- **Security:** submit a POST without a CSRF token and confirm it is rejected; verify user A cannot see user B’s records.

## Notes

The AI coach provides educational guidance from the data entered into this app. It is not a substitute for a qualified financial adviser, tax professional, or legal professional. Keep `.env`, local databases, and API keys out of source control.
