import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path

from flask import Flask, flash, jsonify, redirect, render_template, request, send_from_directory, url_for
from flask_login import current_user
from flask.sessions import SecureCookieSessionInterface
from werkzeug.middleware.proxy_fix import ProxyFix

from config import Config
from extensions import csrf, db, login_manager
from models import User


class PreviewSessionInterface(SecureCookieSessionInterface):
    """Use cross-site cookie attributes only when reached through HTTPS Preview."""

    def get_cookie_secure(self, app):
        return request.is_secure or super().get_cookie_secure(app)

    def get_cookie_samesite(self, app):
        if request.is_secure:
            return "None"
        return super().get_cookie_samesite(app)


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)
    app.session_interface = PreviewSessionInterface()
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    @app.template_filter("from_json")
    def from_json(value):
        try:
            parsed = json.loads(value or "{}")
            return parsed if isinstance(parsed, dict) else {}
        except (TypeError, ValueError, json.JSONDecodeError):
            return {}

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.context_processor
    def inject_helpers():
        def format_currency(value, currency=None):
            try:
                number = float(value or 0)
            except (TypeError, ValueError):
                number = 0.0
            return f"{currency or getattr(current_user, 'currency', 'USD')} {number:,.2f}"

        return {"today": date.today(), "format_currency": format_currency}

    @app.route("/health")
    def health():
        return jsonify({"status": "ok", "service": "personal-finance-advisor"})

    @app.route("/manus-routes.json")
    def route_manifest():
        return send_from_directory(app.static_folder, "manus-routes.json", mimetype="application/json")

    @app.cli.command("init-db")
    def init_db_command():
        db.create_all()
        print("Database initialized.")

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/403.html"), 403

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template("errors/500.html"), 500

    from routes.ai import ai_bp
    from routes.auth import auth_bp
    from routes.budget import budget_bp
    from routes.dashboard import dashboard_bp
    from routes.finance import finance_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(finance_bp)
    app.register_blueprint(budget_bp)
    app.register_blueprint(ai_bp)
    app.register_blueprint(dashboard_bp)

    with app.app_context():
        db.create_all()

    return app


app = create_app()


def run_app(with_ngrok=False):
    port = int(os.getenv("PORT", app.config.get("PORT", 3000)))
    tunnel = None
    if with_ngrok:
        try:
            from pyngrok import conf, ngrok

            auth_token = os.getenv("NGROK_AUTH_TOKEN", "")
            if auth_token:
                conf.get_default().auth_token = auth_token
            tunnel = ngrok.connect(port, "http")
            print(f"Ngrok public URL: {tunnel.public_url}")
        except Exception as exc:
            print(f"Ngrok could not start: {exc}")
            print("Continuing with the local Flask server.")
    print(f"Local URL: http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
    if tunnel:
        try:
            from pyngrok import ngrok

            ngrok.disconnect(tunnel.public_url)
        except Exception:
            pass


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Personal Finance Advisor Bot")
    parser.add_argument("--ngrok", action="store_true", help="Expose the local server through Ngrok")
    args = parser.parse_args()
    run_app(with_ngrok=args.ngrok)
