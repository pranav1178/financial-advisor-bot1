from datetime import date
from decimal import Decimal

from flask_wtf import FlaskForm
from wtforms import (
    BooleanField,
    DateField,
    DecimalField,
    EmailField,
    IntegerField,
    PasswordField,
    SelectField,
    StringField,
    SubmitField,
    TextAreaField,
)
from wtforms.validators import (
    DataRequired,
    Email,
    EqualTo,
    Length,
    NumberRange,
    Optional,
    ValidationError,
)


class RegisterForm(FlaskForm):
    name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=120)])
    email = EmailField("Email", validators=[DataRequired(), Email(), Length(max=255)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8, max=128)])
    confirm_password = PasswordField(
        "Confirm password", validators=[DataRequired(), EqualTo("password")]
    )
    submit = SubmitField("Create account")


class LoginForm(FlaskForm):
    email = EmailField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    remember = BooleanField("Remember me")
    submit = SubmitField("Sign in")


class ProfileForm(FlaskForm):
    name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=120)])
    monthly_income = DecimalField(
        "Monthly income", validators=[DataRequired(), NumberRange(min=0)], places=2
    )
    financial_goals = TextAreaField("Financial goals", validators=[Optional(), Length(max=2000)])
    currency = SelectField(
        "Currency",
        choices=[("USD", "USD — US Dollar"), ("EUR", "EUR — Euro"), ("GBP", "GBP — Pound"), ("INR", "INR — Rupee"), ("CAD", "CAD — Canadian Dollar"), ("AUD", "AUD — Australian Dollar")],
        validators=[DataRequired()],
    )
    submit = SubmitField("Save profile")


class IncomeForm(FlaskForm):
    source = StringField("Source", validators=[DataRequired(), Length(max=120)])
    amount = DecimalField("Amount", validators=[DataRequired(), NumberRange(min=0.01)], places=2)
    date = DateField("Date", validators=[DataRequired()], default=date.today)
    submit = SubmitField("Save income")


class ExpenseForm(FlaskForm):
    amount = DecimalField("Amount", validators=[DataRequired(), NumberRange(min=0.01)], places=2)
    category_id = SelectField("Category", coerce=int, validators=[DataRequired()])
    date = DateField("Date", validators=[DataRequired()], default=date.today)
    note = StringField("Note", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Save expense")


class CategoryForm(FlaskForm):
    name = StringField("Category name", validators=[DataRequired(), Length(min=2, max=80)])
    submit = SubmitField("Add category")


class SavingsGoalForm(FlaskForm):
    name = StringField("Goal name", validators=[DataRequired(), Length(max=120)])
    target_amount = DecimalField(
        "Target amount", validators=[DataRequired(), NumberRange(min=0.01)], places=2
    )
    current_amount = DecimalField(
        "Current amount", validators=[DataRequired(), NumberRange(min=0)], places=2
    )
    target_date = DateField("Target date", validators=[Optional()])
    submit = SubmitField("Save goal")

    def validate_current_amount(self, field):
        if self.target_amount.data is not None and field.data is not None and field.data > self.target_amount.data:
            raise ValidationError("Current amount cannot exceed the target amount.")


class BudgetForm(FlaskForm):
    category_id = SelectField("Category", coerce=int, validators=[DataRequired()])
    amount = DecimalField("Monthly limit", validators=[DataRequired(), NumberRange(min=0.01)], places=2)
    year = IntegerField("Year", validators=[DataRequired(), NumberRange(min=2020, max=2100)])
    month = SelectField(
        "Month",
        coerce=int,
        choices=[(i, date(2000, i, 1).strftime("%B")) for i in range(1, 13)],
        validators=[DataRequired()],
    )
    submit = SubmitField("Save budget")


class MonthForm(FlaskForm):
    year = IntegerField("Year", validators=[DataRequired(), NumberRange(min=2020, max=2100)])
    month = SelectField(
        "Month",
        coerce=int,
        choices=[(i, date(2000, i, 1).strftime("%B")) for i in range(1, 13)],
        validators=[DataRequired()],
    )
    submit = SubmitField("View month")


class DeleteForm(FlaskForm):
    submit = SubmitField("Delete")
