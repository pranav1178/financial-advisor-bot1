from datetime import datetime
from decimal import Decimal

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from extensions import db


class TimestampMixin:
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )


class User(UserMixin, TimestampMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    monthly_income = db.Column(db.Numeric(12, 2), default=Decimal("0.00"), nullable=False)
    financial_goals = db.Column(db.Text, default="", nullable=False)
    currency = db.Column(db.String(3), default="USD", nullable=False)

    incomes = db.relationship("Income", backref="user", cascade="all, delete-orphan", lazy=True)
    expenses = db.relationship("Expense", backref="user", cascade="all, delete-orphan", lazy=True)
    categories = db.relationship(
        "ExpenseCategory", backref="user", cascade="all, delete-orphan", lazy=True
    )
    budgets = db.relationship("Budget", backref="user", cascade="all, delete-orphan", lazy=True)
    reports = db.relationship(
        "MonthlyReport", backref="user", cascade="all, delete-orphan", lazy=True
    )
    savings_goals = db.relationship(
        "SavingsGoal", backref="user", cascade="all, delete-orphan", lazy=True
    )
    recommendations = db.relationship(
        "AIRecommendation", backref="user", cascade="all, delete-orphan", lazy=True
    )

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def __repr__(self) -> str:
        return f"<User {self.email}>"


class Income(TimestampMixin, db.Model):
    __tablename__ = "incomes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    source = db.Column(db.String(120), nullable=False)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    date = db.Column(db.Date, nullable=False)


class ExpenseCategory(TimestampMixin, db.Model):
    __tablename__ = "expense_categories"
    __table_args__ = (db.UniqueConstraint("user_id", "name", name="uq_user_category_name"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = db.Column(db.String(80), nullable=False)
    is_default = db.Column(db.Boolean, default=False, nullable=False)

    expenses = db.relationship("Expense", backref="category", lazy=True)
    budgets = db.relationship("Budget", backref="category", lazy=True)


class Expense(TimestampMixin, db.Model):
    __tablename__ = "expenses"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    category_id = db.Column(
        db.Integer, db.ForeignKey("expense_categories.id", ondelete="RESTRICT"), nullable=False
    )
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    date = db.Column(db.Date, nullable=False)
    note = db.Column(db.String(255), default="", nullable=False)


class Budget(TimestampMixin, db.Model):
    __tablename__ = "budgets"
    __table_args__ = (
        db.UniqueConstraint(
            "user_id", "category_id", "year", "month", name="uq_user_budget_month"
        ),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    category_id = db.Column(
        db.Integer, db.ForeignKey("expense_categories.id", ondelete="CASCADE"), nullable=False
    )
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    month = db.Column(db.Integer, nullable=False)

    @property
    def period_label(self) -> str:
        return f"{self.year}-{self.month:02d}"


class MonthlyReport(TimestampMixin, db.Model):
    __tablename__ = "monthly_reports"
    __table_args__ = (db.UniqueConstraint("user_id", "year", "month", name="uq_user_report_month"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    month = db.Column(db.Integer, nullable=False)
    summary_json = db.Column(db.Text, default="{}", nullable=False)
    generated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class SavingsGoal(TimestampMixin, db.Model):
    __tablename__ = "savings_goals"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    target_amount = db.Column(db.Numeric(12, 2), nullable=False)
    current_amount = db.Column(db.Numeric(12, 2), default=Decimal("0.00"), nullable=False)
    target_date = db.Column(db.Date, nullable=True)

    @property
    def progress_percent(self) -> float:
        target = float(self.target_amount or 0)
        if target <= 0:
            return 0.0
        return min(100.0, round(float(self.current_amount or 0) / target * 100, 1))

    @property
    def is_complete(self) -> bool:
        return float(self.current_amount or 0) >= float(self.target_amount or 0)


class AIRecommendation(TimestampMixin, db.Model):
    __tablename__ = "ai_recommendations"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    recommendation_type = db.Column(db.String(80), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    month = db.Column(db.Integer, nullable=False)
    content_json = db.Column(db.Text, default="{}", nullable=False)
    provider = db.Column(db.String(40), default="unknown", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    @property
    def period_label(self) -> str:
        return f"{self.year}-{self.month:02d}"
