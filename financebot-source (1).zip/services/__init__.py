"""Application services for finance aggregation and AI recommendations."""
