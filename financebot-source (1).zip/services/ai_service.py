import json
import re
from datetime import datetime, timezone
from typing import Any


def _extract_json(text: str) -> dict:
    if not text:
        raise ValueError("The AI provider returned an empty response.")
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if not match:
            raise ValueError("The AI provider did not return valid JSON.")
        parsed = json.loads(match.group(0))
    if not isinstance(parsed, dict):
        raise ValueError("The AI response must be a JSON object.")
    return parsed


def _number(value: Any, default: float = 0.0, minimum=None, maximum=None) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        result = default
    if minimum is not None:
        result = max(minimum, result)
    if maximum is not None:
        result = min(maximum, result)
    return round(result, 2)


def _string(value: Any, limit: int = 2000) -> str:
    if value is None:
        return ""
    return str(value).strip()[:limit]


def _string_list(value: Any, limit: int = 12) -> list[str]:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    return [_string(item, 500) for item in value if isinstance(item, (str, int, float)) and _string(item, 500)][
        :limit
    ]


def _analysis_value(value: Any) -> dict | str:
    if isinstance(value, (dict, str)):
        return value
    return {}


def _budget_rows(value: Any) -> list[dict]:
    if isinstance(value, dict):
        value = [{"category": key, "amount": amount} for key, amount in value.items()]
    if not isinstance(value, list):
        return []
    rows = []
    for item in value[:20]:
        if not isinstance(item, dict):
            continue
        category = _string(item.get("category"), 100)
        if not category:
            continue
        rows.append(
            {
                "category": category,
                "amount": _number(item.get("amount"), minimum=0),
                "rationale": _string(item.get("rationale"), 500),
            }
        )
    return rows


def normalize_response(data: dict, feature: str) -> dict:
    score = _number(
        data.get("financial_health_score", data.get("health_score", 0)),
        minimum=0,
        maximum=100,
    )
    actions = data.get("actionable_recommendations", data.get("recommendations", []))
    budget_plan = data.get("budget_plan", data.get("personalized_budget", []))
    return {
        "feature": feature,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "summary": _string(data.get("summary", data.get("analysis", ""))),
        "budget_plan": _budget_rows(budget_plan),
        "spending_analysis": _analysis_value(data.get("spending_analysis", data.get("analysis", {}))),
        "savings_recommendations": _string_list(
            data.get("savings_recommendations", data.get("savings", [])), limit=12
        ),
        "financial_health_score": score,
        "health_explanation": _string(data.get("health_explanation", data.get("explanation", ""))),
        "cost_optimization": _string_list(
            data.get("cost_optimization", data.get("cost_optimization_suggestions", [])), limit=12
        ),
        "emergency_fund": _string(data.get("emergency_fund", data.get("emergency_fund_guidance", ""))),
        "actionable_recommendations": _string_list(actions, limit=12),
    }


def _schema_instruction() -> str:
    return """Return only valid JSON (no markdown fences) with these keys: summary (string), budget_plan (array of objects with category, amount, rationale), spending_analysis (object or string), savings_recommendations (array of strings), financial_health_score (number from 0 to 100), health_explanation (string), cost_optimization (array of strings), emergency_fund (string), actionable_recommendations (array of strings)."""


def build_prompt(feature: str, context: dict) -> str:
    feature_instructions = {
        "budget": "Create a personalized monthly budget plan. Use the user's actual spending and goals; explain how allocations differ from a generic 50/30/20 plan.",
        "spending": "Analyze spending patterns, identify the biggest categories and possible waste, and suggest practical changes.",
        "savings": "Recommend realistic savings actions and prioritization for the user's goals, cash flow, and spending patterns.",
        "health": "Score financial health from 0 to 100 using cash flow, savings rate, budget adherence, and emergency-fund readiness; explain the score.",
        "optimization": "Find cost-optimization opportunities and rank them by likely impact and ease.",
        "emergency": "Give emergency-fund guidance, including a target range and a practical path to build it based on the user's data.",
    }
    return (
        "You are a careful personal finance coach. You must not invent transactions or claim certainty about unknown details. "
        f"{feature_instructions.get(feature, feature_instructions['spending'])} "
        "Use the user's currency and be concise, supportive, and actionable. "
        f"{_schema_instruction()}\n\nUser finance context:\n{json.dumps(context, indent=2, default=str)}"
    )


def _call_gemini(api_key: str, prompt: str, temperature: float) -> str:
    import google.generativeai as genai

    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(
        prompt,
        generation_config={"temperature": temperature, "response_mime_type": "application/json"},
    )
    return getattr(response, "text", "")


def _call_openai(api_key: str, model_name: str, prompt: str, temperature: float) -> str:
    from openai import OpenAI

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model_name,
        temperature=temperature,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": "You return safe, structured JSON financial coaching responses."},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content or ""


def _success(provider: str, feature: str, raw: str) -> dict:
    return {"ok": True, "provider": provider, "data": normalize_response(_extract_json(raw), feature)}


def generate_recommendation(feature: str, context: dict, config) -> dict:
    prompt = build_prompt(feature, context)
    if not config.get("GEMINI_API_KEY") and not config.get("OPENAI_API_KEY"):
        return {
            "ok": False,
            "provider": "none",
            "error": "AI is not configured yet. Add GEMINI_API_KEY or OPENAI_API_KEY to your .env file.",
        }

    failures = []
    if config.get("GEMINI_API_KEY"):
        try:
            raw = _call_gemini(config["GEMINI_API_KEY"], prompt, config.get("AI_TEMPERATURE", 0.2))
            return _success("gemini", feature, raw)
        except Exception as exc:
            failures.append(("gemini", exc))

    if config.get("OPENAI_API_KEY"):
        try:
            raw = _call_openai(
                config["OPENAI_API_KEY"],
                config.get("OPENAI_MODEL", "gpt-4o-mini"),
                prompt,
                config.get("AI_TEMPERATURE", 0.2),
            )
            return _success("openai", feature, raw)
        except Exception as exc:
            failures.append(("openai", exc))

    provider = " -> ".join(name for name, _ in failures) or "unknown"
    detail = "; ".join(f"{name}: {exc}" for name, exc in failures)
    return {
        "ok": False,
        "provider": provider,
        "error": "The configured AI services could not complete this request. Please try again later.",
        "detail": detail if config.get("FLASK_ENV") == "development" else "",
    }
