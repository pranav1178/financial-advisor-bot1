import calendar
from datetime import date
from decimal import Decimal

from sqlalchemy import func

from extensions import db
from models import Budget, Expense, ExpenseCategory, Income, SavingsGoal


def month_bounds(year: int, month: int):
    if not 2020 <= int(year) <= 2100 or not 1 <= int(month) <= 12:
        raise ValueError("Invalid reporting period")
    start = date(year, month, 1)
    last_day = calendar.monthrange(year, month)[1]
    return start, date(year, month, last_day)


def normalize_period(year=None, month=None):
    current = date.today()
    try:
        candidate_year = int(year if year is not None else current.year)
        candidate_month = int(month if month is not None else current.month)
        if 2020 <= candidate_year <= 2100 and 1 <= candidate_month <= 12:
            return candidate_year, candidate_month
    except (TypeError, ValueError):
        pass
    return current.year, current.month


def shift_month(year: int, month: int, offset: int):
    index = year * 12 + month - 1 + offset
    return index // 12, index % 12 + 1


def amount_sum(query) -> Decimal:
    value = query.scalar() or Decimal("0")
    return Decimal(value)


def month_totals(user_id: int, year: int, month: int) -> dict:
    start, end = month_bounds(year, month)
    income = amount_sum(
        db.session.query(func.sum(Income.amount)).filter(
            Income.user_id == user_id, Income.date >= start, Income.date <= end
        )
    )
    expenses = amount_sum(
        db.session.query(func.sum(Expense.amount)).filter(
            Expense.user_id == user_id, Expense.date >= start, Expense.date <= end
        )
    )
    return {
        "income": income,
        "expenses": expenses,
        "net": income - expenses,
        "savings_rate": round(float((income - expenses) / income * 100), 1) if income else 0.0,
    }


def category_breakdown(user_id: int, year: int, month: int) -> list[dict]:
    start, end = month_bounds(year, month)
    rows = (
        db.session.query(ExpenseCategory.name, func.sum(Expense.amount).label("total"))
        .join(Expense, Expense.category_id == ExpenseCategory.id)
        .filter(
            Expense.user_id == user_id,
            Expense.date >= start,
            Expense.date <= end,
        )
        .group_by(ExpenseCategory.id, ExpenseCategory.name)
        .order_by(func.sum(Expense.amount).desc())
        .all()
    )
    total = sum((Decimal(row.total or 0) for row in rows), Decimal("0"))
    return [
        {
            "category": row.name,
            "amount": float(row.total or 0),
            "percentage": round(float((Decimal(row.total or 0) / total) * 100), 1) if total else 0,
        }
        for row in rows
    ]


def budget_performance(user_id: int, year: int, month: int) -> list[dict]:
    start, end = month_bounds(year, month)
    budgets = (
        Budget.query.filter_by(user_id=user_id, year=year, month=month)
        .join(ExpenseCategory)
        .order_by(ExpenseCategory.name.asc())
        .all()
    )
    result = []
    for budget in budgets:
        actual = amount_sum(
            db.session.query(func.sum(Expense.amount)).filter(
                Expense.user_id == user_id,
                Expense.category_id == budget.category_id,
                Expense.date >= start,
                Expense.date <= end,
            )
        )
        limit = Decimal(budget.amount or 0)
        result.append(
            {
                "budget": budget,
                "category": budget.category.name,
                "limit": limit,
                "actual": actual,
                "remaining": limit - actual,
                "percent": round(float(actual / limit * 100), 1) if limit else 0,
                "overspent": actual > limit,
            }
        )
    return result


def trend_data(user_id: int, year: int, month: int, periods: int = 6) -> list[dict]:
    data = []
    for offset in range(-(periods - 1), 1):
        trend_year, trend_month = shift_month(year, month, offset)
        totals = month_totals(user_id, trend_year, trend_month)
        data.append(
            {
                "label": f"{calendar.month_abbr[trend_month]} {str(trend_year)[2:]}",
                "year": trend_year,
                "month": trend_month,
                "income": float(totals["income"]),
                "expenses": float(totals["expenses"]),
            }
        )
    return data


def dashboard_context(user_id: int, year: int, month: int) -> dict:
    totals = month_totals(user_id, year, month)
    breakdown = category_breakdown(user_id, year, month)
    budgets = budget_performance(user_id, year, month)
    goals = SavingsGoal.query.filter_by(user_id=user_id).order_by(SavingsGoal.target_date.asc()).all()
    overspending_count = sum(1 for item in budgets if item["overspent"])
    return {
        "totals": totals,
        "breakdown": breakdown,
        "budgets": budgets,
        "goals": goals,
        "trend": trend_data(user_id, year, month),
        "overspending_count": overspending_count,
        "period": f"{year}-{month:02d}",
    }


def ai_context(user, year: int, month: int) -> dict:
    context = dashboard_context(user.id, year, month)
    incomes = (
        Income.query.filter_by(user_id=user.id)
        .order_by(Income.date.desc())
        .limit(12)
        .all()
    )
    expenses = (
        Expense.query.filter_by(user_id=user.id)
        .order_by(Expense.date.desc())
        .limit(30)
        .all()
    )
    return {
        "profile": {
            "name": user.name,
            "monthly_income": float(user.monthly_income or 0),
            "currency": user.currency,
            "financial_goals": user.financial_goals,
        },
        "period": {"year": year, "month": month},
        "totals": {key: float(value) if isinstance(value, Decimal) else value for key, value in context["totals"].items()},
        "category_breakdown": context["breakdown"],
        "budgets": [
            {
                "category": item["category"],
                "limit": float(item["limit"]),
                "actual": float(item["actual"]),
                "overspent": item["overspent"],
            }
            for item in context["budgets"]
        ],
        "savings_goals": [
            {
                "name": goal.name,
                "target": float(goal.target_amount),
                "current": float(goal.current_amount),
                "progress_percent": goal.progress_percent,
                "target_date": goal.target_date.isoformat() if goal.target_date else None,
            }
            for goal in context["goals"]
        ],
        "recent_income": [
            {"source": item.source, "amount": float(item.amount), "date": item.date.isoformat()}
            for item in incomes
        ],
        "recent_expenses": [
            {
                "category": item.category.name,
                "amount": float(item.amount),
                "date": item.date.isoformat(),
                "note": item.note,
            }
            for item in expenses
        ],
    }
