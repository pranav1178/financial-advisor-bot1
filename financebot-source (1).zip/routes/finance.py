from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import current_user, login_required
from sqlalchemy.exc import IntegrityError

from extensions import db
from forms import CategoryForm, DeleteForm, ExpenseForm, IncomeForm, SavingsGoalForm
from models import Expense, ExpenseCategory, Income, SavingsGoal


finance_bp = Blueprint("finance", __name__)


def category_choices():
    categories = ExpenseCategory.query.filter_by(user_id=current_user.id).order_by(ExpenseCategory.name).all()
    return [(category.id, category.name) for category in categories]


@finance_bp.route("/income")
@login_required
def income_list():
    records = Income.query.filter_by(user_id=current_user.id).order_by(Income.date.desc(), Income.id.desc()).all()
    return render_template("finance/income.html", records=records, delete_form=DeleteForm())


@finance_bp.route("/income/add", methods=["GET", "POST"])
@login_required
def income_add():
    form = IncomeForm()
    if form.validate_on_submit():
        db.session.add(
            Income(user_id=current_user.id, source=form.source.data.strip(), amount=form.amount.data, date=form.date.data)
        )
        db.session.commit()
        flash("Income record added.", "success")
        return redirect(url_for("finance.income_list"))
    return render_template("finance/income_form.html", form=form, title="Add income")


@finance_bp.route("/income/<int:record_id>/edit", methods=["GET", "POST"])
@login_required
def income_edit(record_id):
    record = Income.query.filter_by(id=record_id, user_id=current_user.id).first_or_404()
    form = IncomeForm(obj=record)
    if form.validate_on_submit():
        record.source = form.source.data.strip()
        record.amount = form.amount.data
        record.date = form.date.data
        db.session.commit()
        flash("Income record updated.", "success")
        return redirect(url_for("finance.income_list"))
    return render_template("finance/income_form.html", form=form, title="Edit income")


@finance_bp.route("/income/<int:record_id>/delete", methods=["POST"])
@login_required
def income_delete(record_id):
    record = Income.query.filter_by(id=record_id, user_id=current_user.id).first_or_404()
    db.session.delete(record)
    db.session.commit()
    flash("Income record deleted.", "info")
    return redirect(url_for("finance.income_list"))


@finance_bp.route("/expenses")
@login_required
def expense_list():
    records = (
        Expense.query.filter_by(user_id=current_user.id)
        .order_by(Expense.date.desc(), Expense.id.desc())
        .all()
    )
    return render_template("finance/expenses.html", records=records, delete_form=DeleteForm())


@finance_bp.route("/expenses/add", methods=["GET", "POST"])
@login_required
def expense_add():
    form = ExpenseForm()
    form.category_id.choices = category_choices()
    if form.validate_on_submit():
        category = ExpenseCategory.query.filter_by(id=form.category_id.data, user_id=current_user.id).first()
        if not category:
            flash("Choose a valid category.", "error")
            return render_template("finance/expense_form.html", form=form, title="Add expense")
        db.session.add(
            Expense(
                user_id=current_user.id,
                category_id=category.id,
                amount=form.amount.data,
                date=form.date.data,
                note=(form.note.data or "").strip(),
            )
        )
        db.session.commit()
        flash("Expense recorded.", "success")
        return redirect(url_for("finance.expense_list"))
    return render_template("finance/expense_form.html", form=form, title="Add expense")


@finance_bp.route("/expenses/<int:record_id>/edit", methods=["GET", "POST"])
@login_required
def expense_edit(record_id):
    record = Expense.query.filter_by(id=record_id, user_id=current_user.id).first_or_404()
    form = ExpenseForm(obj=record)
    form.category_id.choices = category_choices()
    if form.validate_on_submit():
        category = ExpenseCategory.query.filter_by(id=form.category_id.data, user_id=current_user.id).first()
        if not category:
            flash("Choose a valid category.", "error")
            return render_template("finance/expense_form.html", form=form, title="Edit expense")
        record.category_id = category.id
        record.amount = form.amount.data
        record.date = form.date.data
        record.note = (form.note.data or "").strip()
        db.session.commit()
        flash("Expense updated.", "success")
        return redirect(url_for("finance.expense_list"))
    return render_template("finance/expense_form.html", form=form, title="Edit expense")


@finance_bp.route("/expenses/<int:record_id>/delete", methods=["POST"])
@login_required
def expense_delete(record_id):
    record = Expense.query.filter_by(id=record_id, user_id=current_user.id).first_or_404()
    db.session.delete(record)
    db.session.commit()
    flash("Expense deleted.", "info")
    return redirect(url_for("finance.expense_list"))


@finance_bp.route("/categories", methods=["GET", "POST"])
@login_required
def categories():
    form = CategoryForm()
    if form.validate_on_submit():
        name = form.name.data.strip()
        if ExpenseCategory.query.filter_by(user_id=current_user.id, name=name).first():
            flash("That category already exists.", "error")
        else:
            db.session.add(ExpenseCategory(user_id=current_user.id, name=name, is_default=False))
            db.session.commit()
            flash("Custom category added.", "success")
            return redirect(url_for("finance.categories"))
    records = ExpenseCategory.query.filter_by(user_id=current_user.id).order_by(ExpenseCategory.name).all()
    return render_template("finance/categories.html", categories=records, form=form, delete_form=DeleteForm())


@finance_bp.route("/categories/<int:category_id>/delete", methods=["POST"])
@login_required
def category_delete(category_id):
    category = ExpenseCategory.query.filter_by(id=category_id, user_id=current_user.id).first_or_404()
    if category.is_default:
        flash("Default categories cannot be deleted.", "error")
    elif category.expenses or category.budgets:
        flash("This category is in use and cannot be deleted.", "error")
    else:
        db.session.delete(category)
        db.session.commit()
        flash("Category deleted.", "info")
    return redirect(url_for("finance.categories"))


@finance_bp.route("/savings")
@login_required
def savings_list():
    goals = SavingsGoal.query.filter_by(user_id=current_user.id).order_by(SavingsGoal.target_date.asc()).all()
    return render_template("finance/savings.html", goals=goals, delete_form=DeleteForm())


@finance_bp.route("/savings/add", methods=["GET", "POST"])
@login_required
def savings_add():
    form = SavingsGoalForm()
    if form.validate_on_submit():
        db.session.add(
            SavingsGoal(
                user_id=current_user.id,
                name=form.name.data.strip(),
                target_amount=form.target_amount.data,
                current_amount=form.current_amount.data,
                target_date=form.target_date.data,
            )
        )
        db.session.commit()
        flash("Savings goal added.", "success")
        return redirect(url_for("finance.savings_list"))
    return render_template("finance/savings_form.html", form=form, title="Add savings goal")


@finance_bp.route("/savings/<int:goal_id>/edit", methods=["GET", "POST"])
@login_required
def savings_edit(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()
    form = SavingsGoalForm(obj=goal)
    if form.validate_on_submit():
        goal.name = form.name.data.strip()
        goal.target_amount = form.target_amount.data
        goal.current_amount = form.current_amount.data
        goal.target_date = form.target_date.data
        db.session.commit()
        flash("Savings goal updated.", "success")
        return redirect(url_for("finance.savings_list"))
    return render_template("finance/savings_form.html", form=form, title="Edit savings goal")


@finance_bp.route("/savings/<int:goal_id>/delete", methods=["POST"])
@login_required
def savings_delete(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()
    db.session.delete(goal)
    db.session.commit()
    flash("Savings goal deleted.", "info")
    return redirect(url_for("finance.savings_list"))
