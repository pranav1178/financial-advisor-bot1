from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy.exc import IntegrityError

from extensions import db
from forms import LoginForm, ProfileForm, RegisterForm
from models import ExpenseCategory, User


auth_bp = Blueprint("auth", __name__)

DEFAULT_CATEGORIES = [
    "Housing",
    "Food",
    "Transport",
    "Utilities",
    "Health",
    "Personal",
    "Entertainment",
    "Debt",
    "Other",
]


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    form = RegisterForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
            return render_template("auth/register.html", form=form)
        user = User(name=form.name.data.strip(), email=email)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.flush()
        db.session.add_all(
            [ExpenseCategory(user_id=user.id, name=name, is_default=True) for name in DEFAULT_CATEGORIES]
        )
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash("We could not create that account. Please try again.", "error")
            return render_template("auth/register.html", form=form)
        login_user(user)
        flash("Welcome to your finance workspace.", "success")
        return redirect(url_for("dashboard.index"))
    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.strip().lower()).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember.data)
            flash("Welcome back.", "success")
            return redirect(url_for("dashboard.index"))
        flash("Invalid email or password.", "error")
    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
def logout():
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    form = ProfileForm(obj=current_user)
    if form.validate_on_submit():
        current_user.name = form.name.data.strip()
        current_user.monthly_income = form.monthly_income.data
        current_user.financial_goals = (form.financial_goals.data or "").strip()
        current_user.currency = form.currency.data
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("auth.profile"))
    return render_template("auth/profile.html", form=form)
