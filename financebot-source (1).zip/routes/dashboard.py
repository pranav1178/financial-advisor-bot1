import json
from datetime import date
from decimal import Decimal

from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from extensions import db
from forms import MonthForm
from models import AIRecommendation, MonthlyReport
from services.finance_service import dashboard_context, normalize_period


dashboard_bp = Blueprint("dashboard", __name__)


def selected_period():
    current = date.today()
    return normalize_period(request.args.get("year", current.year), request.args.get("month", current.month))


def report_for(user_id: int, year: int, month: int, context: dict) -> MonthlyReport:
    report = MonthlyReport.query.filter_by(user_id=user_id, year=year, month=month).first()
    payload = {
        "period": f"{year}-{month:02d}",
        "totals": {key: float(value) if isinstance(value, Decimal) else value for key, value in context["totals"].items()},
        "breakdown": context["breakdown"],
        "budgets": [
            {
                "category": item["category"],
                "limit": float(item["limit"]),
                "actual": float(item["actual"]),
                "overspent": item["overspent"],
            }
            for item in context["budgets"]
        ],
    }
    if not report:
        report = MonthlyReport(user_id=user_id, year=year, month=month, summary_json=json.dumps(payload))
        db.session.add(report)
    else:
        report.summary_json = json.dumps(payload)
    db.session.commit()
    return report


@dashboard_bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    form = MonthForm()
    year, month = selected_period()
    if form.validate_on_submit():
        return redirect(url_for("dashboard.index", year=form.year.data, month=form.month.data))
    form.year.data = year
    form.month.data = month
    context = dashboard_context(current_user.id, year, month)
    return render_template("dashboard.html", form=form, year=year, month=month, **context)


@dashboard_bp.route("/reports", methods=["GET", "POST"])
@login_required
def reports():
    form = MonthForm()
    year, month = selected_period()
    if form.validate_on_submit():
        return redirect(url_for("dashboard.report_detail", year=form.year.data, month=form.month.data))
    form.year.data = year
    form.month.data = month
    context = dashboard_context(current_user.id, year, month)
    report = report_for(current_user.id, year, month, context)
    recommendations = (
        AIRecommendation.query.filter_by(user_id=current_user.id, year=year, month=month)
        .order_by(AIRecommendation.created_at.desc())
        .all()
    )
    return render_template(
        "reports/monthly.html",
        form=form,
        report=report,
        recommendations=recommendations,
        year=year,
        month=month,
        **context,
    )


@dashboard_bp.route("/reports/<int:year>/<int:month>")
@login_required
def report_detail(year, month):
    if not 2020 <= year <= 2100 or not 1 <= month <= 12:
        return redirect(url_for("dashboard.reports"))
    return redirect(url_for("dashboard.reports", year=year, month=month))


@dashboard_bp.route("/api/chart-data")
@login_required
def chart_data():
    year, month = selected_period()
    context = dashboard_context(current_user.id, year, month)
    return jsonify(
        {
            "breakdown": context["breakdown"],
            "trend": context["trend"],
            "budgets": [
                {
                    "category": item["category"],
                    "limit": float(item["limit"]),
                    "actual": float(item["actual"]),
                }
                for item in context["budgets"]
            ],
        }
    )
