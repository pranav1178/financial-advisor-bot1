"""Blueprint package for the Personal Finance Advisor Bot."""
