from datetime import date

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from sqlalchemy.exc import IntegrityError

from extensions import db
from forms import BudgetForm, DeleteForm
from models import Budget, ExpenseCategory
from services.finance_service import budget_performance, normalize_period


budget_bp = Blueprint("budget", __name__, url_prefix="/budgets")


def set_category_choices(form):
    categories = ExpenseCategory.query.filter_by(user_id=current_user.id).order_by(ExpenseCategory.name).all()
    form.category_id.choices = [(category.id, category.name) for category in categories]


def period_values():
    current = date.today()
    return normalize_period(request.args.get("year", current.year), request.args.get("month", current.month))


@budget_bp.route("")
@login_required
def list_budgets():
    year, month = period_values()
    rows = budget_performance(current_user.id, year, month)
    return render_template("budgets/list.html", rows=rows, year=year, month=month, delete_form=DeleteForm())


@budget_bp.route("/add", methods=["GET", "POST"])
@login_required
def add_budget():
    form = BudgetForm()
    set_category_choices(form)
    if not form.year.data:
        form.year.data = date.today().year
    if not form.month.data:
        form.month.data = date.today().month
    if form.validate_on_submit():
        category = ExpenseCategory.query.filter_by(id=form.category_id.data, user_id=current_user.id).first()
        if not category:
            flash("Choose a valid category.", "error")
        elif Budget.query.filter_by(
            user_id=current_user.id,
            category_id=category.id,
            year=form.year.data,
            month=form.month.data,
        ).first():
            flash("A budget already exists for that category and month.", "error")
        else:
            db.session.add(
                Budget(
                    user_id=current_user.id,
                    category_id=category.id,
                    amount=form.amount.data,
                    year=form.year.data,
                    month=form.month.data,
                )
            )
            db.session.commit()
            flash("Budget saved.", "success")
            return redirect(url_for("budget.list_budgets", year=form.year.data, month=form.month.data))
    return render_template("budgets/form.html", form=form, title="Add budget")


@budget_bp.route("/<int:budget_id>/edit", methods=["GET", "POST"])
@login_required
def edit_budget(budget_id):
    budget = Budget.query.filter_by(id=budget_id, user_id=current_user.id).first_or_404()
    form = BudgetForm(obj=budget)
    set_category_choices(form)
    if form.validate_on_submit():
        category = ExpenseCategory.query.filter_by(id=form.category_id.data, user_id=current_user.id).first()
        if not category:
            flash("Choose a valid category.", "error")
            return render_template("budgets/form.html", form=form, title="Edit budget")
        duplicate = Budget.query.filter(
            Budget.user_id == current_user.id,
            Budget.category_id == form.category_id.data,
            Budget.year == form.year.data,
            Budget.month == form.month.data,
            Budget.id != budget.id,
        ).first()
        if duplicate:
            flash("A budget already exists for that category and month.", "error")
        else:
            budget.category_id = form.category_id.data
            budget.amount = form.amount.data
            budget.year = form.year.data
            budget.month = form.month.data
            db.session.commit()
            flash("Budget updated.", "success")
            return redirect(url_for("budget.list_budgets", year=budget.year, month=budget.month))
    return render_template("budgets/form.html", form=form, title="Edit budget")


@budget_bp.route("/<int:budget_id>/delete", methods=["POST"])
@login_required
def delete_budget(budget_id):
    budget = Budget.query.filter_by(id=budget_id, user_id=current_user.id).first_or_404()
    year, month = budget.year, budget.month
    db.session.delete(budget)
    db.session.commit()
    flash("Budget deleted.", "info")
    return redirect(url_for("budget.list_budgets", year=year, month=month))
