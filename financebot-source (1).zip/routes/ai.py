import json
from datetime import date

from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from extensions import db
from forms import MonthForm
from models import AIRecommendation
from services.ai_service import generate_recommendation
from services.finance_service import ai_context, normalize_period


ai_bp = Blueprint("ai", __name__, url_prefix="/ai")

ALLOWED_FEATURES = {
    "budget": "Personalized budget",
    "spending": "Spending analysis",
    "savings": "Savings recommendations",
    "health": "Financial health score",
    "optimization": "Cost optimization",
    "emergency": "Emergency fund guidance",
}


def requested_period():
    current = date.today()
    return normalize_period(
        request.form.get("year", request.args.get("year", current.year)),
        request.form.get("month", request.args.get("month", current.month)),
    )


@ai_bp.route("/recommendations")
@login_required
def recommendations():
    year, month = requested_period()
    form = MonthForm()
    form.year.data = year
    form.month.data = month
    history = (
        AIRecommendation.query.filter_by(user_id=current_user.id, year=year, month=month)
        .order_by(AIRecommendation.created_at.desc())
        .all()
    )
    return render_template(
        "ai/recommendations.html",
        form=form,
        history=history,
        year=year,
        month=month,
        features=ALLOWED_FEATURES,
    )


@ai_bp.route("/generate/<feature>", methods=["POST"])
@login_required
def generate(feature):
    if feature not in ALLOWED_FEATURES:
        flash("That AI action is not available.", "error")
        return redirect(url_for("ai.recommendations"))
    year, month = requested_period()
    result = generate_recommendation(feature, ai_context(current_user, year, month), current_app.config)
    if not result["ok"]:
        flash(result["error"], "error")
        return redirect(url_for("ai.recommendations", year=year, month=month))
    db.session.add(
        AIRecommendation(
            user_id=current_user.id,
            recommendation_type=feature,
            year=year,
            month=month,
            provider=result["provider"],
            content_json=json.dumps(result["data"]),
        )
    )
    db.session.commit()
    flash(f"{ALLOWED_FEATURES[feature]} generated with {result['provider'].title()}.", "success")
    return redirect(url_for("ai.recommendations", year=year, month=month))
